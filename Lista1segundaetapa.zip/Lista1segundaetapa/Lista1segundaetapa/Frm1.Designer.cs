﻿namespace Lista1segundaetapa
{
    partial class Frm1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm1));
            this.pnl1 = new System.Windows.Forms.Panel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.exibirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exibirFrm1 = new System.Windows.Forms.ToolStripMenuItem();
            this.exibirFrm2 = new System.Windows.Forms.ToolStripMenuItem();
            this.exibirFrm3 = new System.Windows.Forms.ToolStripMenuItem();
            this.exibirFrm4 = new System.Windows.Forms.ToolStripMenuItem();
            this.pnl1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl1
            // 
            this.pnl1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(79)))), ((int)(((byte)(118)))), ((int)(((byte)(130)))));
            this.pnl1.Controls.Add(this.menuStrip1);
            this.pnl1.Location = new System.Drawing.Point(12, 12);
            this.pnl1.Name = "pnl1";
            this.pnl1.Size = new System.Drawing.Size(776, 204);
            this.pnl1.TabIndex = 0;
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(96)))), ((int)(((byte)(146)))), ((int)(((byte)(161)))));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exibirToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(776, 24);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // exibirToolStripMenuItem
            // 
            this.exibirToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(96)))), ((int)(((byte)(146)))), ((int)(((byte)(161)))));
            this.exibirToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exibirFrm1,
            this.exibirFrm2,
            this.exibirFrm3,
            this.exibirFrm4});
            this.exibirToolStripMenuItem.Name = "exibirToolStripMenuItem";
            this.exibirToolStripMenuItem.Size = new System.Drawing.Size(47, 20);
            this.exibirToolStripMenuItem.Text = "Exibir";
            // 
            // exibirFrm1
            // 
            this.exibirFrm1.Image = ((System.Drawing.Image)(resources.GetObject("exibirFrm1.Image")));
            this.exibirFrm1.Name = "exibirFrm1";
            this.exibirFrm1.Size = new System.Drawing.Size(133, 22);
            this.exibirFrm1.Text = "Questão 01";
            this.exibirFrm1.Click += new System.EventHandler(this.exibirFrm1_Click);
            // 
            // exibirFrm2
            // 
            this.exibirFrm2.Image = ((System.Drawing.Image)(resources.GetObject("exibirFrm2.Image")));
            this.exibirFrm2.Name = "exibirFrm2";
            this.exibirFrm2.Size = new System.Drawing.Size(133, 22);
            this.exibirFrm2.Text = "Questão 02";
            this.exibirFrm2.Click += new System.EventHandler(this.exibirFrm2_Click);
            // 
            // exibirFrm3
            // 
            this.exibirFrm3.Image = ((System.Drawing.Image)(resources.GetObject("exibirFrm3.Image")));
            this.exibirFrm3.Name = "exibirFrm3";
            this.exibirFrm3.Size = new System.Drawing.Size(133, 22);
            this.exibirFrm3.Text = "Questão 03";
            this.exibirFrm3.Click += new System.EventHandler(this.exibirFrm3_Click);
            // 
            // exibirFrm4
            // 
            this.exibirFrm4.Image = ((System.Drawing.Image)(resources.GetObject("exibirFrm4.Image")));
            this.exibirFrm4.Name = "exibirFrm4";
            this.exibirFrm4.Size = new System.Drawing.Size(133, 22);
            this.exibirFrm4.Text = "Questão 04";
            this.exibirFrm4.Click += new System.EventHandler(this.exibirFrm4_Click);
            // 
            // Frm1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pnl1);
            this.Name = "Frm1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Frm1";
            this.pnl1.ResumeLayout(false);
            this.pnl1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem exibirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exibirFrm1;
        private System.Windows.Forms.ToolStripMenuItem exibirFrm2;
        private System.Windows.Forms.ToolStripMenuItem exibirFrm3;
        private System.Windows.Forms.ToolStripMenuItem exibirFrm4;
    }
}

