﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lista1segundaetapa
{
    public partial class Frm4 : Form
    {
        public Frm4()
        {
            InitializeComponent();
        }

        private void exibirFrm1_Click(object sender, EventArgs e)
        {
            Frm1 frm1 = new Frm1();
            this.Hide();
            frm1.ShowDialog();
        }

        private void exibirFrm2_Click(object sender, EventArgs e)
        {
            Frm2 frm2 = new Frm2();
            this.Hide();
            frm2.ShowDialog();
        }

        private void exibirFrm3_Click(object sender, EventArgs e)
        {
            Frm3 frm3 = new Frm3();
            this.Hide();
            frm3.ShowDialog();
        }

        private void exibirFrm4_Click(object sender, EventArgs e)
        {
            Frm4 frm4 = new Frm4();
            this.Hide();
            frm4.ShowDialog();
        }
    }
}
