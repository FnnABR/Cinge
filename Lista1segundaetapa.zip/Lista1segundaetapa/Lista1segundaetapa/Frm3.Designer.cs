﻿namespace Lista1segundaetapa
{
    partial class Frm3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm3));
            this.pnl3 = new System.Windows.Forms.Panel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.exibirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exibirFrm1 = new System.Windows.Forms.ToolStripMenuItem();
            this.exibirFrm2 = new System.Windows.Forms.ToolStripMenuItem();
            this.exibirFrm3 = new System.Windows.Forms.ToolStripMenuItem();
            this.exibirFrm4 = new System.Windows.Forms.ToolStripMenuItem();
            this.pnl3.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl3
            // 
            this.pnl3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(159)))), ((int)(((byte)(237)))), ((int)(((byte)(165)))));
            this.pnl3.Controls.Add(this.menuStrip1);
            this.pnl3.Location = new System.Drawing.Point(12, 12);
            this.pnl3.Name = "pnl3";
            this.pnl3.Size = new System.Drawing.Size(776, 204);
            this.pnl3.TabIndex = 1;
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(110)))), ((int)(((byte)(74)))));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exibirToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(776, 24);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // exibirToolStripMenuItem
            // 
            this.exibirToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(110)))), ((int)(((byte)(74)))));
            this.exibirToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exibirFrm1,
            this.exibirFrm2,
            this.exibirFrm3,
            this.exibirFrm4});
            this.exibirToolStripMenuItem.Name = "exibirToolStripMenuItem";
            this.exibirToolStripMenuItem.Size = new System.Drawing.Size(47, 20);
            this.exibirToolStripMenuItem.Text = "Exibir";
            // 
            // exibirFrm1
            // 
            this.exibirFrm1.Image = ((System.Drawing.Image)(resources.GetObject("exibirFrm1.Image")));
            this.exibirFrm1.Name = "exibirFrm1";
            this.exibirFrm1.Size = new System.Drawing.Size(133, 22);
            this.exibirFrm1.Text = "Questão 01";
            this.exibirFrm1.Click += new System.EventHandler(this.exibirFrm1_Click);
            // 
            // exibirFrm2
            // 
            this.exibirFrm2.Image = ((System.Drawing.Image)(resources.GetObject("exibirFrm2.Image")));
            this.exibirFrm2.Name = "exibirFrm2";
            this.exibirFrm2.Size = new System.Drawing.Size(133, 22);
            this.exibirFrm2.Text = "Questão 02";
            this.exibirFrm2.Click += new System.EventHandler(this.exibirFrm2_Click);
            // 
            // exibirFrm3
            // 
            this.exibirFrm3.Image = ((System.Drawing.Image)(resources.GetObject("exibirFrm3.Image")));
            this.exibirFrm3.Name = "exibirFrm3";
            this.exibirFrm3.Size = new System.Drawing.Size(133, 22);
            this.exibirFrm3.Text = "Questão 03";
            this.exibirFrm3.Click += new System.EventHandler(this.exibirFrm3_Click);
            // 
            // exibirFrm4
            // 
            this.exibirFrm4.Image = ((System.Drawing.Image)(resources.GetObject("exibirFrm4.Image")));
            this.exibirFrm4.Name = "exibirFrm4";
            this.exibirFrm4.Size = new System.Drawing.Size(133, 22);
            this.exibirFrm4.Text = "Questão 04";
            this.exibirFrm4.Click += new System.EventHandler(this.exibirFrm4_Click);
            // 
            // Frm3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pnl3);
            this.Name = "Frm3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Frm3";
            this.pnl3.ResumeLayout(false);
            this.pnl3.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl3;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem exibirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exibirFrm1;
        private System.Windows.Forms.ToolStripMenuItem exibirFrm2;
        private System.Windows.Forms.ToolStripMenuItem exibirFrm3;
        private System.Windows.Forms.ToolStripMenuItem exibirFrm4;
    }
}